public class Variables{
	
	public static void main(String[] args){
		
		int i = 8, j = 5;
		float x = 0.005F, y = -0.01F;
		char c = 'c', d = 'd';
		
		
		System.out.println(i <= j);
		System.out.println(c > d);
		System.out.println(x >= 0);
		System.out.println(x < y--);
		System.out.println(j != 6);
		System.out.println(c == 99);
		System.out.println(!(i <= j));
		System.out.println(!(c == 99));
		System.out.println(!(x > 0));
		System.out.println(	-j == i - 13 );
		System.out.println(++x > 0);
		System.out.println(y-- < 1);
		System.out.println(c > d || c > 0);
		System.out.println(5 * (i + j) > 'c');
		System.out.println(2 * x + y == 0);
		//System.out.println(2 * x + (y == 0));
		System.out.println(x + y  >= 0);
		System.out.println(x < ++y);
		System.out.println(-(i + j) != -i + j);
		System.out.println(i <= j && i >= c);
		System.out.println(i > 0 && j < 5);
		System.out.println(i > 0 || j < 5);
		System.out.println(	x > y && i > 0 || j < 5);
		
		
		
		
		
		
		
		
		
	

		
	}
	
	
}